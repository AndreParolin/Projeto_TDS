<footer>
    <div>
        <p>&copy; <?php echo date("Y"); ?> DriveCars. Todos os direitos reservados.</p>
    </div>
</footer>