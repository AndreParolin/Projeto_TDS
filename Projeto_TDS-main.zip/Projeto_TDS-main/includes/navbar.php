<div class="navbar">
    <a href="index.php">Home</a>
    <a href="#">Veículos</a>
    <a href="#">Marcas</a>
    <a href="contato.php">Contato</a>
    <a href="sobre.php">Sobre Nós</a>
    <a href="login.php">Login</a>
    <a href="cadastro.php">Cadastro</a>
</div>